export declare class SecureDB {
    private path;
    private size;
    static install(): void;
    private isInitialized;
    constructor(path: string, size?: number);
    private ensureInitialized;
    set(key: string, value: any): boolean;
    get<T = any>(key: string): T | undefined;
    clear(): boolean;
    benchmark(): number;
}
export default SecureDB;
//# sourceMappingURL=index.d.ts.map