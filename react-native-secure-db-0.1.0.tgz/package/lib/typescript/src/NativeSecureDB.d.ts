import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    install(): void;
    getVersion(): string;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeSecureDB.d.ts.map