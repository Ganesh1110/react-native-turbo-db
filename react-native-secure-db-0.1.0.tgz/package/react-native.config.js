module_path = __dirname;

module.exports = {
  dependency: {
    platforms: {
      android: {
        cmakeListsPath: 'android/CMakeLists.txt',
      },
      ios: {
        podspecPath: 'SecureDB.podspec',
      },
    },
  },
};
